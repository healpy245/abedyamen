@extends('layouts.kaman')

@section('title', __('workspace.title'))
@section('tag', __('workspace.tag'))

@section('content')
    @php
        $user = auth()->user();
        $projects = $user->accessibleProjects();
        $isAdmin = (bool) $user->is_admin;
        $firstName = trim(explode(' ', trim($user->name))[0] ?? $user->name);
    @endphp

    <div class="page-container">
        <div class="mx-auto w-full max-w-6xl space-y-8">

            <section class="hero-panel">
                <div class="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
                    <div class="max-w-xl">
                        <p class="kaman-eyebrow mb-3">{{ __('workspace.welcome_back') }}</p>
                        <h1 class="text-3xl sm:text-4xl font-semibold text-[#2b1e11] mb-3">
                            {{ __('workspace.hello', ['name' => $firstName]) }}
                        </h1>
                        <p class="text-sm text-[#7c6a56] leading-relaxed">
                            @if($isAdmin)
                                {{ __('workspace.access_admin') }}
                            @elseif(count($projects) === 1)
                                {{ __('workspace.access_one') }}
                            @elseif(count($projects) > 1)
                                {{ __('workspace.access_many', ['count' => count($projects)]) }}
                            @else
                                {{ __('workspace.access_none') }}
                            @endif
                        </p>
                    </div>

                    <div class="hero-metrics">
                        <div class="metric-card">
                            <p class="text-[0.6rem] font-semibold uppercase tracking-[0.18em] text-[#a78a6c] mb-1">
                                {{ __('workspace.tools_available') }}
                            </p>
                            <p class="text-2xl font-semibold text-[#2b1e11]">{{ count($projects) }}</p>
                        </div>
                        <div class="metric-card">
                            <p class="text-[0.6rem] font-semibold uppercase tracking-[0.18em] text-[#a78a6c] mb-1">
                                {{ __('workspace.access_level') }}
                            </p>
                            <p class="text-2xl font-semibold text-[#2b1e11]">
                                {{ $isAdmin ? __('workspace.admin') : __('app.member') }}
                            </p>
                        </div>
                    </div>
                </div>
            </section>

            @if(count($projects) > 0)
                <section>
                    <p class="kaman-eyebrow mb-4">{{ __('workspace.your_tools') }}</p>

                    <div class="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
                        @foreach($projects as $project)
                            <a href="{{ $project->url() }}" class="kaman-card kaman-card--link group p-6 flex flex-col">
                                <div class="flex items-start justify-between gap-3 mb-4">
                                    <span class="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-[#f47a2e]/12 border border-[#f47a2e]/25 text-sm font-bold text-[#f16229]">
                                        {{ $project->initials() }}
                                    </span>
                                    <svg class="h-5 w-5 text-[#d8c4a8] transition group-hover:text-[#f47a2e] rtl:rotate-180"
                                         viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                        <path fill-rule="evenodd" d="M3 10a.75.75 0 01.75-.75h10.638L10.23 5.29a.75.75 0 111.04-1.08l5.5 5.25a.75.75 0 010 1.08l-5.5 5.25a.75.75 0 11-1.04-1.08l4.158-3.96H3.75A.75.75 0 013 10z" clip-rule="evenodd"/>
                                    </svg>
                                </div>

                                <h2 class="text-lg font-semibold text-[#2b1e11] mb-2">{{ $project->label() }}</h2>
                                <p class="text-sm text-[#7c6a56] leading-relaxed flex-1">{{ $project->description() }}</p>

                                <span class="mt-5 inline-flex items-center gap-2 text-[0.65rem] font-semibold uppercase tracking-[0.28em] text-[#f47a2e]">
                                    <span class="h-1.5 w-1.5 rounded-full bg-[#f47a2e]"></span>
                                    {{ __('app.open') }}
                                </span>
                            </a>
                        @endforeach
                    </div>
                </section>
            @else
                <section class="kaman-card p-12 text-center">
                    <span class="mx-auto mb-4 inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-[#f47a2e]/10 border border-[#f47a2e]/20">
                        <svg class="h-6 w-6 text-[#f47a2e]" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                            <path fill-rule="evenodd" d="M10 1a4.5 4.5 0 00-4.5 4.5V9H5a2 2 0 00-2 2v6a2 2 0 002 2h10a2 2 0 002-2v-6a2 2 0 00-2-2h-.5V5.5A4.5 4.5 0 0010 1zm3 8V5.5a3 3 0 10-6 0V9h6z" clip-rule="evenodd"/>
                        </svg>
                    </span>
                    <h2 class="text-lg font-semibold text-[#2b1e11] mb-2">{{ __('workspace.no_tools_title') }}</h2>
                    <p class="mx-auto max-w-sm text-sm text-[#7c6a56]">
                        {{ __('workspace.no_tools_body') }}
                    </p>
                </section>
            @endif

            @if($isAdmin)
                <section>
                    <p class="kaman-eyebrow mb-4">{{ __('workspace.administration') }}</p>

                    <a href="{{ route('ai-chatbot.admin.settings.edit') }}"
                       class="kaman-card kaman-card--link group p-6 flex items-center gap-5">
                        <span class="inline-flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-[#2b1e11]/8 border border-[#2b1e11]/15 text-xs font-bold text-[#2b1e11]">
                            ADM
                        </span>
                        <div class="min-w-0 flex-1">
                            <h2 class="text-lg font-semibold text-[#2b1e11] mb-1">{{ __('workspace.chatbot_settings') }}</h2>
                            <p class="text-sm text-[#7c6a56] leading-relaxed">
                                {{ __('workspace.chatbot_settings_desc') }}
                            </p>
                        </div>
                        <svg class="h-5 w-5 shrink-0 text-[#d8c4a8] transition group-hover:text-[#f47a2e] rtl:rotate-180"
                             viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                            <path fill-rule="evenodd" d="M3 10a.75.75 0 01.75-.75h10.638L10.23 5.29a.75.75 0 111.04-1.08l5.5 5.25a.75.75 0 010 1.08l-5.5 5.25a.75.75 0 11-1.04-1.08l4.158-3.96H3.75A.75.75 0 013 10z" clip-rule="evenodd"/>
                        </svg>
                    </a>
                </section>
            @endif

            <p class="pt-2 text-center text-xs text-[#a78a6c]">
                {{ __('workspace.signed_in_as', ['email' => $user->email]) }}
            </p>
        </div>
    </div>
@endsection
